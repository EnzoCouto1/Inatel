public class CarneDeOuro extends Pratos{
    private String ModelCorte;

    public String getModelCorte() {
        return ModelCorte;
    }

    public void setModelCorte(String modelCorte) {
        ModelCorte = modelCorte;
    }
}
